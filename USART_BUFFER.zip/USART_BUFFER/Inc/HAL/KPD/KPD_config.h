/*
 * KPD_config.h
 *
 *  Created on: Sep 2, 2022
 *      Author: M-TECH
 */

#ifndef HAL_KPD_KPD_CONFIG_H_
#define HAL_KPD_KPD_CONFIG_H_



#endif /* HAL_KPD_KPD_CONFIG_H_ */
