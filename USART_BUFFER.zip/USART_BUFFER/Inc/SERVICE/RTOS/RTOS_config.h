/*
 * RTOS_conf.h
 *
 *  Created on: Aug 22, 2022
 *      Author: Loka
 */

#ifndef SERVICE_RTOS_RTOS_CONF_H_
#define SERVICE_RTOS_RTOS_CONF_H_

#define  NUM_OF_TASKS   4

#endif /* SERVICE_RTOS_RTOS_CONF_H_ */
