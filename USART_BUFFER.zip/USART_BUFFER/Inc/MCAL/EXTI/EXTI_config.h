/*
 * EXTI_config.h
 *
 *  Created on: Aug 18, 2022
 *      Author: M-TECH
 */

#ifndef MCAL_EXTI_EXTI_CONFIG_H_
#define MCAL_EXTI_EXTI_CONFIG_H_



#endif /* MCAL_EXTI_EXTI_CONFIG_H_ */
