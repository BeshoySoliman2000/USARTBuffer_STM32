#ifndef I2C_CONFIG_H_
#define I2C_CONFIG_H_


#endif