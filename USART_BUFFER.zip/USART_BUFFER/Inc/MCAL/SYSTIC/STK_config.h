/*
 * STK_configuration.h
 *
 *  Created on: Aug 21, 2022
 *      Author: ELHOSSENI
 */

#ifndef MCAL_STK_STK_CONFIGURATION_H_
#define MCAL_STK_STK_CONFIGURATION_H_

/*MSTK_SOURCE_AHB_8
 * MSTK_SOURCE_AHB*/

#define MSTK_CLK_SOURCE   MSTK_SOURCE_AHB_8

#endif /* MCAL_STK_STK_CONFIGURATION_H_ */
