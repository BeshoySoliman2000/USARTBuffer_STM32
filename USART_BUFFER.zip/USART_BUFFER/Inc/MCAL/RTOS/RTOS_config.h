#ifndef		RTOS_CONFIG_H
#define		RTOS_CONFIG_H

#define		NUM_OF_TASKS			3

#endif