/*
 * SPI_config.h
 *
 *  Created on: May 19, 2022
 *      Author: Asmaa Hashim
 */

#ifndef SPI_CONFIG_H_
#define SPI_CONFIG_H_



/* Max number of SPI channels */
#define      SPI_MAX_CH          2



#endif /* SPI_CONFIG_H_ */
