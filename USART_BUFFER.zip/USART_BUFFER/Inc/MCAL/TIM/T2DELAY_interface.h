#ifndef T2DELAY_INTERFACE_H_
#define T2DELAY_INTERFACE_H_

void MTIMER2_voidInitTimer2Delay(void);
void MTIMER2_voidStartDealyInMicroSeconds(u32 Copy_u32Delay);

#endif