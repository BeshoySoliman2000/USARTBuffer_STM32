/*
 * OS_config.h
 *
 *  Created on: Sep 7, 2020
 *      Author: Asmaa Hashim
 */

#ifndef OS_CONFIG_H_
#define OS_CONFIG_H_


#define NUM_OF_TASKS  (2)


#endif /* OS_CONFIG_H_ */
